const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const store = require('../models/dataStore');

// List services
router.get('/', (req, res) => {
  res.json(store.services);
});

// Create service
router.post('/', (req, res) => {
  const { name, price } = req.body;
  if (!name) return res.status(400).json({ error: 'name required' });
  const service = { id: uuidv4(), name, price: price||0 };
  store.services.push(service);
  res.status(201).json({ message: 'service created', service });
});

// Delete service
router.delete('/:id', (req, res) => {
  const idx = store.services.findIndex(s => s.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'service not found' });
  store.services.splice(idx,1);
  res.json({ message: 'service deleted' });
});

module.exports = router;
