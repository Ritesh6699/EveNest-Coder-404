const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const store = require('../models/dataStore');

// Create booking
// POST /api/bookings
router.post('/', (req, res) => {
  const { userId, hallId, date, startTime, endTime, services: serviceIds } = req.body;
  if (!userId || !hallId || !date || !startTime || !endTime) {
    return res.status(400).json({ error: 'userId, hallId, date, startTime and endTime required' });
  }
  const user = store.users.find(u => u.id === userId);
  const hall = store.halls.find(h => h.id === hallId);
  if (!user) return res.status(404).json({ error: 'user not found' });
  if (!hall) return res.status(404).json({ error: 'hall not found' });

  // check conflicts
  const conflict = store.bookings.find(b => b.hallId === hallId && b.date === date && !(b.endTime <= startTime || b.startTime >= endTime));
  if (conflict) return res.status(409).json({ error: 'time slot not available', conflict });

  // calculate price
  const durationHours = (parseInt(endTime.split(':')[0]) + parseInt(endTime.split(':')[1])/60) - (parseInt(startTime.split(':')[0]) + parseInt(startTime.split(':')[1])/60);
  const hallCost = (hall.pricePerHour || 0) * Math.max(0, durationHours);
  let servicesList = [];
  let servicesCost = 0;
  if (serviceIds && Array.isArray(serviceIds)) {
    servicesList = store.services.filter(s => serviceIds.includes(s.id));
    servicesCost = servicesList.reduce((acc,s)=>acc+(s.price||0),0);
  }
  const totalPrice = hallCost + servicesCost;

  const booking = {
    id: uuidv4(),
    userId, hallId, date, startTime, endTime,
    services: servicesList.map(s=>s.id),
    totalPrice
  };
  store.bookings.push(booking);
  res.status(201).json({ message: 'booking created', booking });
});

// List bookings
router.get('/', (req, res) => {
  res.json(store.bookings);
});

// Get booking by id
router.get('/:id', (req, res) => {
  const b = store.bookings.find(x => x.id === req.params.id);
  if (!b) return res.status(404).json({ error: 'booking not found' });
  res.json(b);
});

// Get bookings for a user
router.get('/user/:userId', (req, res) => {
  const user = store.users.find(u => u.id === req.params.userId);
  if (!user) return res.status(404).json({ error: 'user not found' });
  const bookings = store.bookings.filter(b => b.userId === req.params.userId);
  res.json(bookings);
});

// Update booking
router.put('/:id', (req, res) => {
  const b = store.bookings.find(x => x.id === req.params.id);
  if (!b) return res.status(404).json({ error: 'booking not found' });
  const { date, startTime, endTime, services: serviceIds } = req.body;
  if (date) b.date = date;
  if (startTime) b.startTime = startTime;
  if (endTime) b.endTime = endTime;
  if (serviceIds) {
    const servicesList = store.services.filter(s => serviceIds.includes(s.id));
    b.services = servicesList.map(s=>s.id);
  }
  res.json({ message: 'booking updated', booking: b });
});

// Cancel booking
router.delete('/:id', (req, res) => {
  const idx = store.bookings.findIndex(x => x.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'booking not found' });
  store.bookings.splice(idx,1);
  res.json({ message: 'booking cancelled' });
});

module.exports = router;
