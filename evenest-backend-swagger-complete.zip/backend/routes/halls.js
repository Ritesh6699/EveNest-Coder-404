const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const store = require('../models/dataStore');

// Create hall
// POST /api/halls
router.post('/', (req, res) => {
  const { name, location, capacity, pricePerHour, amenities } = req.body;
  if (!name || !location) return res.status(400).json({ error: 'name and location required' });
  const hall = { id: uuidv4(), name, location, capacity: capacity||0, pricePerHour: pricePerHour||0, amenities: amenities||[] };
  store.halls.push(hall);
  res.status(201).json({ message: 'hall created', hall });
});

// List halls
router.get('/', (req, res) => {
  res.json(store.halls);
});

// Get hall by id
router.get('/:id', (req, res) => {
  const hall = store.halls.find(h => h.id === req.params.id);
  if (!hall) return res.status(404).json({ error: 'hall not found' });
  res.json(hall);
});

// Update hall
router.put('/:id', (req, res) => {
  const hall = store.halls.find(h => h.id === req.params.id);
  if (!hall) return res.status(404).json({ error: 'hall not found' });
  const { name, location, capacity, pricePerHour, amenities } = req.body;
  if (name) hall.name = name;
  if (location) hall.location = location;
  if (capacity !== undefined) hall.capacity = capacity;
  if (pricePerHour !== undefined) hall.pricePerHour = pricePerHour;
  if (amenities) hall.amenities = amenities;
  res.json({ message: 'hall updated', hall });
});

// Delete hall
router.delete('/:id', (req, res) => {
  const idx = store.halls.findIndex(h => h.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'hall not found' });
  store.halls.splice(idx,1);
  res.json({ message: 'hall deleted' });
});

// Check availability for a date (simple logic: checks bookings for same date and time overlap)
// GET /api/halls/:id/availability?date=YYYY-MM-DD&start=HH:MM&end=HH:MM
router.get('/:id/availability', (req, res) => {
  const hall = store.halls.find(h => h.id === req.params.id);
  if (!hall) return res.status(404).json({ error: 'hall not found' });
  const { date, start, end } = req.query;
  if (!date || !start || !end) return res.status(400).json({ error: 'date, start and end query params required' });

  const conflicts = store.bookings.filter(b => b.hallId === hall.id && b.date === date && !(b.endTime <= start || b.startTime >= end));
  const available = conflicts.length === 0;
  res.json({ hallId: hall.id, date, start, end, available, conflicts });
});

module.exports = router;
