const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const store = require('../models/dataStore');

// Register
// POST /api/users/register
router.post('/register', (req, res) => {
  const { username, email, password } = req.body;
  if (!username || !email || !password) {
    return res.status(400).json({ error: 'username, email and password required' });
  }
  const exists = store.users.find(u => u.email === email);
  if (exists) return res.status(409).json({ error: 'email already registered' });

  const user = { id: uuidv4(), username, email, password };
  store.users.push(user);
  res.status(201).json({ message: 'user created', user });
});

// Simple login (in-memory, returns a fake token)
router.post('/login', (req, res) => {
  const { email, password } = req.body;
  const user = store.users.find(u => u.email === email && u.password === password);
  if (!user) return res.status(401).json({ error: 'invalid credentials' });
  // fake token (for demo only)
  const token = Buffer.from(user.id).toString('base64');
  res.json({ message: 'login successful', token, userId: user.id });
});

// CRUD for users
router.get('/', (req, res) => {
  const publicUsers = store.users.map(u => ({ id: u.id, username: u.username, email: u.email }));
  res.json(publicUsers);
});

router.get('/:id', (req, res) => {
  const user = store.users.find(u => u.id === req.params.id);
  if (!user) return res.status(404).json({ error: 'user not found' });
  res.json({ id: user.id, username: user.username, email: user.email });
});

router.put('/:id', (req, res) => {
  const user = store.users.find(u => u.id === req.params.id);
  if (!user) return res.status(404).json({ error: 'user not found' });
  const { username, email, password } = req.body;
  if (username) user.username = username;
  if (email) user.email = email;
  if (password) user.password = password;
  res.json({ message: 'user updated', user: { id: user.id, username: user.username, email: user.email } });
});

router.delete('/:id', (req, res) => {
  const idx = store.users.findIndex(u => u.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'user not found' });
  store.users.splice(idx, 1);
  res.json({ message: 'user deleted' });
});

module.exports = router;
