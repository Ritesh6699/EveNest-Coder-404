const { v4: uuidv4 } = require('uuid');

const users = [
  { id: uuidv4(), username: 'alice', email: 'alice@example.com', password: 'pass123' },
  { id: uuidv4(), username: 'bob', email: 'bob@example.com', password: 'pass456' }
];

const halls = [
  { id: uuidv4(), name: 'Community Hall A', location: 'Margao', capacity: 150, pricePerHour: 1000, amenities: ['sound', 'lights'] },
  { id: uuidv4(), name: 'Banquet Hall B', location: 'Panaji', capacity: 300, pricePerHour: 2500, amenities: ['catering', 'stage'] }
];

const services = [
  { id: uuidv4(), name: 'Pandit', price: 2000 },
  { id: uuidv4(), name: 'Catering Basic', price: 5000 }
];

const bookings = [
  // sample booking structure:
  // { id, userId, hallId, date: 'YYYY-MM-DD', startTime: '18:00', endTime: '22:00', services: [serviceId], totalPrice }
];

module.exports = {
  users,
  halls,
  bookings,
  services
};
