const express = require('express');
const app = express();
const port = process.env.PORT || 3000;
const swaggerUi = require('swagger-ui-express');
const swaggerSpec = require('./swagger');

app.use(express.json());

// Routes
const usersRouter = require('./routes/users');
const hallsRouter = require('./routes/halls');
const bookingsRouter = require('./routes/bookings');
const servicesRouter = require('./routes/services');

app.use('/api/users', usersRouter);
app.use('/api/halls', hallsRouter);
app.use('/api/bookings', bookingsRouter);
app.use('/api/services', servicesRouter);

// Swagger UI
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerSpec));

app.get('/', (req, res) => {
  res.json({ message: 'EveNest Backend (in-memory). Visit /api-docs for API documentation.' });
});

app.listen(port, () => {
  console.log(`EveNest backend listening at http://localhost:${port}`);
  console.log(`Swagger UI: http://localhost:${port}/api-docs`);
});
