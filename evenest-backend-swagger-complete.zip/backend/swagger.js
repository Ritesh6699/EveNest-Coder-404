const swaggerJSDoc = require('swagger-jsdoc');

const options = {
  definition: {
    openapi: '3.0.0',
    info: {
      title: 'EveNest Backend API (Complete)',
      version: '1.0.0',
      description: 'Complete API documentation for EveNest backend with example request/response bodies. Use /api-docs to view and try endpoints.'
    },
    servers: [
      { url: 'http://localhost:3000', description: 'Local server' }
    ],
    components: {
      schemas: {
        User: {
          type: 'object',
          required: ['name','email','password'],
          properties: {
            id: { type: 'string', example: 'u123' },
            name: { type: 'string', example: 'Ritesh Naik' },
            email: { type: 'string', example: 'ritesh@example.com' },
            password: { type: 'string', example: 'strongPassword123' }
          }
        },
        LoginRequest: {
          type: 'object',
          properties: {
            username: { type: 'string', example: 'ritesh' },
            password: { type: 'string', example: '123456' }
          }
        },
        Hall: {
          type: 'object',
          required: ['name','location','capacity'],
          properties: {
            id: { type: 'string', example: 'h100' },
            name: { type: 'string', example: 'Grand Banquet Hall' },
            location: { type: 'string', example: 'MG Road, Mumbai' },
            capacity: { type: 'integer', example: 300 },
            price_per_day: { type: 'number', example: 15000 },
            images: { type: 'array', items: { type: 'string', example: 'https://example.com/img1.jpg' } }
          }
        },
        Booking: {
          type: 'object',
          required: ['userId','hallId','date','startTime','endTime'],
          properties: {
            id: { type: 'string', example: 'b101' },
            userId: { type: 'string', example: 'u123' },
            hallId: { type: 'string', example: 'h100' },
            date: { type: 'string', format: 'date', example: '2025-09-12' },
            startTime: { type: 'string', example: '10:00' },
            endTime: { type: 'string', example: '14:00' }
          }
        },
        Service: {
          type: 'object',
          properties: {
            id: { type: 'string', example: 's200' },
            name: { type: 'string', example: 'Catering' },
            price: { type: 'number', example: 5000 }
          }
        },
        ErrorResponse: {
          type: 'object',
          properties: {
            error: { type: 'string', example: 'Description of the error' }
          }
        }
      }
    },
    paths: {
      "/api/users/register": {
        "post": {
          "tags": ["Users"],
          "summary": "Register new user",
          "requestBody": {
            "required": true,
            "content": {
              "application/json": {
                "schema": { "$ref": "#/components/schemas/User" }
              }
            }
          },
          "responses": {
            "200": {
              "description": "Registration successful",
              "content": {
                "application/json": {
                  "schema": {
                    "type": "object",
                    "properties": {
                      "message": { "type": "string", "example": "Registration successful. Awaiting approval if Hall Owner." },
                      "userId": { "type": "string", "example": "u123" }
                    }
                  }
                }
              }
            },
            "400": { "description": "Bad Request", "content": { "application/json": { "schema": { "$ref": "#/components/schemas/ErrorResponse" } } } }
          }
        }
      },
      "/api/users/login": {
        "post": {
          "tags": ["Users"],
          "summary": "Login user (username/password)",
          "requestBody": {
            "required": true,
            "content": {
              "application/json": {
                "schema": { "$ref": "#/components/schemas/LoginRequest" }
              }
            }
          },
          "responses": {
            "200": {
              "description": "Login successful",
              "content": {
                "application/json": {
                  "schema": {
                    "type": "object",
                    "properties": {
                      "token": { "type": "string", "example": "eyJhbGciOi..." },
                      "user": { "$ref": "#/components/schemas/User" }
                    }
                  }
                }
              }
            },
            "401": { "description": "Unauthorized", "content": { "application/json": { "schema": { "$ref": "#/components/schemas/ErrorResponse" } } } }
          }
        }
      },
      "/api/users": {
        "get": {
          "tags": ["Users"],
          "summary": "Get all users",
          "responses": { "200": { "description": "List of users" } }
        }
      },
      "/api/users/{id}": {
        "get": {
          "tags": ["Users"],
          "summary": "Get user by id",
          "parameters": [{ "name": "id", "in": "path", "required": true, "schema": { "type": "string" } }],
          "responses": { "200": { "description": "User object" }, "404": { "description": "Not Found" } }
        },
        "put": {
          "tags": ["Users"],
          "summary": "Update user by id",
          "parameters": [{ "name": "id", "in": "path", "required": true, "schema": { "type": "string" } }],
          "requestBody": { "required": true, "content": { "application/json": { "schema": { "$ref": "#/components/schemas/User" } } } },
          "responses": { "200": { "description": "Updated" } }
        },
        "delete": {
          "tags": ["Users"],
          "summary": "Delete user by id",
          "parameters": [{ "name": "id", "in": "path", "required": true, "schema": { "type": "string" } }],
          "responses": { "200": { "description": "Deleted" } }
        }
      },
      "/api/halls": {
        "get": {
          "tags": ["Halls"],
          "summary": "Get all halls",
          "responses": { "200": { "description": "List of halls" } }
        },
        "post": {
          "tags": ["Halls"],
          "summary": "Create a new hall",
          "requestBody": { "required": true, "content": { "application/json": { "schema": { "$ref": "#/components/schemas/Hall" } } } },
          "responses": { "201": { "description": "Created" }, "400": { "description": "Bad Request" } }
        }
      },
      "/api/halls/{id}": {
        "get": { "tags": ["Halls"], "summary": "Get hall by id", "parameters": [{ "name": "id", "in": "path", "required": true, "schema": { "type": "string" } }], "responses": { "200": { "description": "OK" } } },
        "put": { "tags": ["Halls"], "summary": "Update hall by id", "parameters": [{ "name": "id", "in": "path", "required": true, "schema": { "type": "string" } }], "requestBody": { "required": true, "content": { "application/json": { "schema": { "$ref": "#/components/schemas/Hall" } } } }, "responses": { "200": { "description": "Updated" } } },
        "delete": { "tags": ["Halls"], "summary": "Delete hall by id", "parameters": [{ "name": "id", "in": "path", "required": true, "schema": { "type": "string" } }], "responses": { "200": { "description": "Deleted" } } }
      },
      "/api/halls/{id}/availability": {
        "get": { "tags": ["Halls"], "summary": "Check availability of a hall for a date range", "parameters": [{ "name": "id", "in": "path", "required": true, "schema": { "type": "string" } }, { "name": "date", "in": "query", "required": false, "schema": { "type": "string", "format": "date" } }], "responses": { "200": { "description": "Availability data" } } }
      },
      "/api/bookings": {
        "get": { "tags": ["Bookings"], "summary": "Get all bookings", "responses": { "200": { "description": "List of bookings" } } },
        "post": { "tags": ["Bookings"], "summary": "Create a booking", "requestBody": { "required": true, "content": { "application/json": { "schema": { "$ref": "#/components/schemas/Booking" } } } }, "responses": { "201": { "description": "Created" }, "400": { "description": "Bad Request" } } }
      },
      "/api/bookings/{id}": {
        "get": { "tags": ["Bookings"], "summary": "Get booking by id", "parameters": [{ "name": "id", "in": "path", "required": true, "schema": { "type": "string" } }], "responses": { "200": { "description": "OK" } } },
        "put": { "tags": ["Bookings"], "summary": "Update booking", "parameters": [{ "name": "id", "in": "path", "required": true, "schema": { "type": "string" } }], "requestBody": { "required": true, "content": { "application/json": { "schema": { "$ref": "#/components/schemas/Booking" } } } }, "responses": { "200": { "description": "Updated" } } },
        "delete": { "tags": ["Bookings"], "summary": "Delete booking", "parameters": [{ "name": "id", "in": "path", "required": true, "schema": { "type": "string" } }], "responses": { "200": { "description": "Deleted" } } }
      },
      "/api/bookings/user/{userId}": {
        "get": { "tags": ["Bookings"], "summary": "Get bookings for a user", "parameters": [{ "name": "userId", "in": "path", "required": true, "schema": { "type": "string" } }], "responses": { "200": { "description": "User bookings" } } }
      },
      "/api/services": {
        "get": { "tags": ["Services"], "summary": "Get all services", "responses": { "200": { "description": "OK" } } },
        "post": { "tags": ["Services"], "summary": "Create a service", "requestBody": { "required": true, "content": { "application/json": { "schema": { "$ref": "#/components/schemas/Service" } } } }, "responses": { "201": { "description": "Created" } } }
      },
      "/api/services/{id}": {
        "delete": { "tags": ["Services"], "summary": "Delete a service", "parameters": [{ "name": "id", "in": "path", "required": true, "schema": { "type": "string" } }], "responses": { "200": { "description": "Deleted" } } }
      }
    }
  },
  apis: []
};

const swaggerSpec = swaggerJSDoc(options);
module.exports = swaggerSpec;
