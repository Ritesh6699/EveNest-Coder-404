# EveNest Backend (Assignment 4)

This is a simple Node.js + Express backend implementing the EveNest API (in-memory) for your Assignment 4.  
It uses an in-memory store (no database) and provides a Swagger UI at `/api-docs`.

## What is included
- Endpoints for Users, Halls, Bookings, Services
- In-memory data (models/dataStore.js)
- Swagger UI (auto-generated basic spec in `swagger.js`)

## Run locally (step-by-step)

1. Unzip the provided `evenest-backend.zip` and open a terminal.
2. `cd backend`
3. Install dependencies:
   ```bash
   npm install
   ```
4. Start the server:
   ```bash
   npm start
   ```
5. Open the API docs in your browser:
   ```
   http://localhost:3000/api-docs
   ```

## Notes
- This is a demo in-memory backend. Restarting the server will reset data.
- Authentication is minimal (login returns a fake token). Do NOT use in production.
- Endpoints match common booking app needs (create bookings, check availability, CRUD for users/halls/services).
